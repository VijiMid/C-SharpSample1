﻿using System;

namespace MyLibrary
{
    public class D
    {
        private int pri2;
        protected int pro2;
        internal int in2;
        protected internal int pi2;
        public int pu2;
    }
}
