Imports System

Module Program
    Sub Main(args As String())
        Console.WriteLine("Hello World from VB!")
    End Sub
End Module
