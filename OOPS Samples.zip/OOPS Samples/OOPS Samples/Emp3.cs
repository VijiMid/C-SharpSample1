﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyNamespace
{
   public class Emp3
    {
        public void DisplayNamespace()
        {
            Console.WriteLine("\tSample Namespace");
        }
    }
}
