﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MyLibrary;
namespace OOPS_Samples
{
    class Program6
    {
        public class A
        {
            private int pri1;
            protected int pro1;
            internal int in1;
            protected internal int pi1;
            public int pu1;
            public void displayA()
            {
                Console.WriteLine("From A Class");
                Console.WriteLine("Private : " + pri1);
                Console.WriteLine("Protected : " + pro1);
                Console.WriteLine("Internal : " + in1);
                Console.WriteLine("protected internal : " + pi1);
                Console.WriteLine("Public : " + pu1);
            }
        }
        public class B:A // inherit - B is sub class , A is base class
        {
            public void displayB()
            {
                Console.WriteLine("From B Class");
                //Console.WriteLine("Private : " + pri1); // error
                Console.WriteLine("Protected : " + pro1);
                Console.WriteLine("Internal : " + in1);
                Console.WriteLine("protected internal : " + pi1);
                Console.WriteLine("Public : " + pu1);
            }
        }
        class C
        {
            Program6.A obj = new Program6.A();
            public void displayC()
            {
                Console.WriteLine("From C Class");
               // Console.WriteLine("Private : " + obj.pri1); // error
               // Console.WriteLine("Protected : " + obj. pro1); // error
                Console.WriteLine("Internal : " + obj.in1);
                Console.WriteLine("protected internal : " + obj.pi1);
                Console.WriteLine("Public : " + obj.pu1);
            }
        }
        static void Main(string[] args) // entry point
        {
            /*
            A a = new A();
            a.displayA();
            */
            /*
            B b = new B();
            b.displayA();
            b.displayB();
            */
            /*
            C c = new C();
            c.displayC();
            */
             D d = new D();
           // Console.WriteLine("From D Class");
             //Console.WriteLine("Private : " +d.pri2); // error
             //Console.WriteLine("Protected : " + d. pro2); // error
             //Console.WriteLine("Internal : " + d.in2);  // error
            //Console.WriteLine("protected internal : " + d.pi2); // error
             Console.WriteLine("Public : " + d.pu2);
        }
        }
}
