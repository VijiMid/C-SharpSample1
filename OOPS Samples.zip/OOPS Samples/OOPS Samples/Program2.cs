﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPS_Samples
{
    class Program2
    {
        /*
        static void Main(string[] args) // entry point
        {
            Corporate.Emp3 e = new Corporate.Emp3();
            e.DisplayEmp();
            Console.WriteLine("From Main method");

            Corporate c = new Corporate();
            c.DisplayConstructor();
        }
        */
    }
}
