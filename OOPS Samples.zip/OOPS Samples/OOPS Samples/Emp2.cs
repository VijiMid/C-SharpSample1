﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPS_Samples
{
    abstract class Emp2
   // sealed class Emp2 // sealed classes cannot inherit into another class.
    {
        public void DisplayEmp()
        {
            Console.WriteLine("*****************************");
            Console.WriteLine("\t1001");
            Console.WriteLine("\tPooja");
            Console.WriteLine("\tPooja@gmail.com");
            Console.WriteLine("*****************************");
        }
    }
    class Project : Emp2 // inheritance
    {
        public void DisplayProject()
        {
            Console.WriteLine("*****************************");
            Console.WriteLine("\tP001");
            Console.WriteLine("\tShopping Cart");
            Console.WriteLine("\tRatan Tata");
            Console.WriteLine("*****************************");
        }
    }
}
