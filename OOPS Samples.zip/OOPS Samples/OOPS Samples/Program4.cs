﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPS_Samples
{
    class Program4
    {
        /*
        static void Main(string[] args) // entry point
        {
            Microsoft.displayMS();  // outer static class
            Microsoft.NormalClass N = new Microsoft.NormalClass(); // Normal inner class with object
            N.displayInnerClass1();

            Microsoft.staticClass.displayInnerClass2(); // Static inner class without object
        }
        */
     }
}
