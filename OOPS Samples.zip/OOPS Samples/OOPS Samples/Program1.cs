﻿using System;

namespace OOPS_Samples
{

    class Program1
    {
        /*
      static void Main(string[] args) // entry point
        {
            //Emp1 e = new Emp1();
            // e.AcceptEmp();
            // e.DisplayEmp();

            // e.DisplayEmp();
            
            Console.WriteLine("Enter Size : ");
            int size =  Convert.ToInt32(Console.ReadLine());
            Emp1[] e = new Emp1[size];
            int  i;
            
            for(i=0;i<size;i++)
            {
                // new used create instance of the object.
                // Instance holds the address of object
                e[i] = new Emp1();                
                e[i].AcceptEmp();
            }
            for (i = 0; i < size; i++)
            {
                e[i].DisplayEmp();
            }
             
            
            Emp2 e2; // object creation -
                     // Error
            e2= new Emp2(); // create instance for the Object
            e2.DisplayEmp();

            Project p = new Project();
            //p.DisplayEmp();
            p.DisplayProject();
             
        }
    */

    }
}
