﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPS_Samples
{
    class Program3
    {
        /*
        static void Main(string[] args) // entry point
        {
            
            CGI.Dotnet d = new CGI.Dotnet();
            d.dotnetContent();

            CGI c = new CGI();
            c.CGIMethod();
             
        }
        */
    }
}
