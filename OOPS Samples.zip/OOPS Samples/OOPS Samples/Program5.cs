﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MyNamespace;

namespace OOPS_Samples
{
    class Program5
    {
        /*
        static void Main(string[] args) // entry point
        {
            Emp3 e = new Emp3();
            e.DisplayNamespace();
        }
        */
    }
}
