﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPS_Samples
{
    class Corporate
    {
        public class Emp3 // inner class 1 with public
        {
            public void DisplayEmp()
            {
                Console.WriteLine("Sample Nested Class - Emp");
            }
        }
        class Salary // inner class 2 with out public
        {
            public void DisplaySalary()
            {
                Console.WriteLine("Sample Nested Class - Salary");
            }
        }
        private Salary s;
        public Corporate()
        {
            Console.WriteLine("From Corporate constructor");
            s = new Salary();
            s.DisplaySalary();
        }
        public void DisplayConstructor()
        {
            Console.WriteLine("From Corporate Method");
        }
    }
}
