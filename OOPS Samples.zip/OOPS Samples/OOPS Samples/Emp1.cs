﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPS_Samples
{
    class Emp1 //user defined class
    {
        int empid;
        string empname;
        string email;
        public void AcceptEmp() // method
        {
            Console.WriteLine("Enter Emp Id");
            empid = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Emp Name");
            empname = Console.ReadLine() ;
            Console.WriteLine("Enter Email");
            email =Console.ReadLine() ;
        }
        public void DisplayEmp()
        {             
            Console.WriteLine("*****************************");
            Console.WriteLine("\tEmp Id :{0}", empid);
            Console.WriteLine("\tEmp Name :{0}", empname);
            Console.WriteLine("\tEmail :{0}", email);
            Console.WriteLine("*****************************");
        }
    }
}
