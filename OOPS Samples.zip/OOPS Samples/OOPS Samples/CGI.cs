﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPS_Samples
{
    class CGI
    {
        public class Dotnet
        {
            public void dotnetContent()
            {
                Console.WriteLine("C sharp Topic ");
            }
        }
         class Java
        {
            public void javaContent()
            {
                Console.WriteLine("Java Topic ");
            }
        }
        private Java j;
        public CGI()
        {
            Console.WriteLine("Constructor from CGI ");
            j = new Java();
            j.javaContent();
        }

        public void CGIMethod()
        {
            Console.WriteLine("Method from CGI ");
        }
    }
}
