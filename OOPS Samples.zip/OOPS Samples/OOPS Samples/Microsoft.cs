﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPS_Samples
{
    //outer class
    static class Microsoft // should not create a namespace at the name of Microsoft. Because its prefdefined namespace
    {
        static int x = 200;
        static public  void displayMS() 
        {
            Console.WriteLine("Sample static class - Microsoft");
        }
        //inner class
        public class NormalClass  // inner class1
        {
            public void displayInnerClass1()
            {
                Console.WriteLine("Sample Normal inner  class - from Microsoft");
            }
        }

        static public class staticClass // inner class2
        {
          static  public void displayInnerClass2()
            {
                Console.WriteLine("Sample Static inner  class - from Microsoft");
            }
        }
    }
}
