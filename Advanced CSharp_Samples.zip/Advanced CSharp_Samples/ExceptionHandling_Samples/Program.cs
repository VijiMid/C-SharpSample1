﻿using System;

namespace ExceptionHandling_Samples
{
    class Program
    {
        /*
        static void Main(string[] args)
        {
            int x,y;
            Console.WriteLine("Enter x : ");
            x = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter y : ");
            y = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(  Exc1.calc(x,y));
        }
        */
        /*
        static void Main(string[] args)
        {
            Console.WriteLine(Exc2.Conversion());
        }
        */
        /*
        static void Main(string[] args)
        {
            try
            {
                Exc3.CheckNull(null); // argument
            }
            catch (ArgumentNullException ex)
            {
                Console.WriteLine("Name is Empty/null value");
            }
        }
        */
        /*
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Name : ");
            string na = Console.ReadLine();
            Console.WriteLine("Enter Age : ");
            int  age =Convert.ToInt32( Console.ReadLine()); //21 , 12

            Exc4.CheckAge(na, age);
        }
        */
        /*
        static void Main(string[] args)
        {
            CGIException C = new CGIException();
        }
        */
        static void Main(string[] args)
        {
            string[] s = { "10", null, "Ruturaj", "70.50", "C", "120" };
            int i = 0, valid = 0, invalid = 0;

            for (i = 0; i < s.Length; i++)
            {
                try
                {
                    if(s[i] == null)
                    {
                        throw new MyException("Sorry, String Should not be null");
                    }
                }
                catch (MyException ex)
                {
                    invalid += 1;
                    continue; // jumping/skipping statement
                }
                valid += 1;
            }
            Console.WriteLine("Valid : {0}", valid);
            Console.WriteLine("Invalid : {0}", invalid);
        }
    }
    }
 
