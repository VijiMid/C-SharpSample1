﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandling_Samples
{
    class Exc1
    {
       public static int calc(int x,int y)
        {
            int c = 0;
            try
            {
                c = x / y;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Cannot divide by zero"); // message / information
                c = x / 2; // give solution to resolve the error
            }
            return c;
        }
    }
}
