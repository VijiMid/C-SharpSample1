﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandling_Samples
{
    class MyException:Exception // Must inherit predefined exception class
    {
        public MyException(String msg):base(msg) // base keyword used to pass the data/value to base class constructor
        {
            Console.WriteLine(msg);
        }
    }
}

/*
 * super(msg)  - in java
 * 
 */