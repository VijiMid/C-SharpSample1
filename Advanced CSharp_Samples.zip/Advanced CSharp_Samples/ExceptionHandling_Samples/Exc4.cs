﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandling_Samples
{
    class Exc4
    {
        public static void CheckAge(string name, int age) // parameter
        {
            try
            {
                if(age>=18 && age<=110)
                {
                    Console.WriteLine(name + " is eligble for vote");
                }
                else
                {
                    throw new Exception("Not eligible for vote");
                }
            }
            catch(Exception e)
            {
                Console.WriteLine(name + " is " + e.Message);
            }
        }
    }
}
