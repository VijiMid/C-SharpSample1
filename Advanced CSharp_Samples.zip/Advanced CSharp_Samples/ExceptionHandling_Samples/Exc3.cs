﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandling_Samples
{
    class Exc3
    {
       public static void CheckNull(string name) // parameter
        {
            if(name==null)
            {
                throw new ArgumentNullException("name");
            }
            else
            {
                Console.WriteLine("Name is : {0}", name);
            }

        }
    }
}
// 
