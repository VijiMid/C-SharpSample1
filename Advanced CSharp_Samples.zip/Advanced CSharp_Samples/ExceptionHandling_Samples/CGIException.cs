﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandling_Samples
{
    class CGIException 
    {
        public CGIException()
        {
            string[] s = { "10", "100", "Ruturaj", "70.50", "C", "120" };
            int i = 0,valid=0,invalid=0;
            
                for (i = 0; i < s.Length;i++)
                {
                try
                {
                   Convert.ToInt32(s[i]) ; // parse/conversion/type cast
                }
                catch (Exception e)
                {
                    invalid += 1;
                    continue; // jumping/skipping statement
                }
                valid += 1;
            }

            Console.WriteLine("Valid : {0}", valid);
            Console.WriteLine("Invalid : {0}", invalid);

        }
    }
}
