﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandling_Samples
{
    // Multiple Catch
    class Exc2
    {
        public static int Conversion()
        {
            int b=0;
            try
            {                
                int[] a = { 10, 20 };   // dense Array            
              b= 100 / a[1]; // Array Index Error
                Console.WriteLine("b is : {0}", b);

               b = a[1] / (a[0] - 5); // Division by zero error
                Console.WriteLine("b is : {0}", b);
            }
            catch(IndexOutOfRangeException ex)
            {
                Console.WriteLine("Enter Valid index");
            }
            catch(DivideByZeroException ex)
            {
                Console.WriteLine("Division by zero Error");
            }
            return b;
        }
    }
}
