﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FileHandlingSamples
{
    class File4
    {
        public void display()
        {
            /*
            Console.WriteLine("Enter Source File Name : ");
            string fname1 = Console.ReadLine();
            Console.WriteLine("Enter Target File Name : ");
            string fname2 = Console.ReadLine();
            //File.Copy(Source , Target, Overwrite)
            File.Copy(fname1, fname2, true); // here copying

            StreamReader sr = File.OpenText(fname2);
                string s = "";
            while((s=sr.ReadLine())!= null)
            {
                Console.WriteLine(s);
            }
            */
            //Folder path - Source and Target
            string sDir=@"D:\CGI1\";
            string tDir = @"E:\CGI1\";
            Console.WriteLine("Enter Source File Name : ");
            string fname1 = Console.ReadLine();
            Console.WriteLine("Enter Target File Name : ");
            string fname2 = Console.ReadLine();

            if(!System.IO.Directory.Exists(tDir))
            {
                System.IO.Directory.CreateDirectory(tDir);
            }
            // Combining folders and files
            string sFile = Path.Combine(sDir, fname1);
            string tFile = Path.Combine(tDir, fname2);

            // here copying
            File.Copy(sFile, tFile, true); 

            // Read the content from new folder path file
            StreamReader sr = File.OpenText(tFile);
            string s = "";
            while ((s = sr.ReadLine()) != null) // EOF - 
            {
                Console.WriteLine(s);
            }
        }
    }
}
