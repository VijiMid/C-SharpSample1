﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FileHandlingSamples
{
    class File3
    {
        public void display()
        {
            Console.WriteLine("Enter File Name : ");
            string fname = Console.ReadLine();

            StreamWriter f = File.CreateText(fname);
            int line = 0;
            Console.WriteLine("How many Lines you want to Write?");
            line = Convert.ToInt32(Console.ReadLine());
            for (int i=1;i<=line;i++)
            {
                f.WriteLine(Console.ReadLine());
            }           
            f.Close();

            StreamReader sr = File.OpenText(fname);
            string s = "";
            while((s = sr.ReadLine()) != null)
            {
                Console.WriteLine(s);
            }
        }
    }
}
