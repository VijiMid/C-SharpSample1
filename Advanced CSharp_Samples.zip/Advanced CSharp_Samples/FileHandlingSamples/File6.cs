﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FileHandlingSamples
{
    class File6
    {
        public void display()
        {
            Console.WriteLine("Enter File Name : ");
            string fname = Console.ReadLine();
            int cnt = 0;
            StreamReader sr = File.OpenText(fname);
            string s = "";
            while ((s = sr.ReadLine()) != null)
            {
                Console.WriteLine(s);
                cnt++;
            }
            Console.WriteLine("Number of Lines : {0}", cnt);

            Console.WriteLine("\nLast Line is : ");
            if (File.Exists(fname))
            {
                string[] lines = File.ReadAllLines(fname);
                Console.Write(lines[cnt-1]);
            }
            Console.WriteLine("\nEnter specific Line No  : ");
            int L = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("\n");
            if (L>=1 && L<=cnt)
            {
                string[] lines = File.ReadAllLines(fname);
                Console.Write(lines[L - 1]);
            }
        }
}
}
