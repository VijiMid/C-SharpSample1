﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FileHandlingSamples
{
    class File5
    {
        public void display()
        { 
                Console.WriteLine("Enter File Name : ");
                string fname = Console.ReadLine();

            if(File.Exists(fname))
                {
                string[] lines = File.ReadAllLines(fname);
                Console.Write(lines[0]);
            } 

            }
        }
}
