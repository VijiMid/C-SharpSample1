﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO; // use the Predefined namespace of IO
namespace FileHandlingSamples
{
    class File1
    {
        public void display()
        {
            Console.WriteLine("Enter File Name : ");
            string fname = Console.ReadLine();

            if (File.Exists(fname))
            {                
                Console.WriteLine("File Name already Exist");
            }
            else
            {
                FileStream f = File.Create(fname);
               
               
            Console.WriteLine("File Created ");
            }
        }
    }
}
