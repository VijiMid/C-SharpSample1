﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FileHandlingSamples
{
    class File2
    {
        public void display()
        {
            Console.WriteLine("Enter File Name : ");
            string fname = Console.ReadLine();
            if(File.Exists(fname))
            {
                File.Delete(fname);
                Console.WriteLine("Deleted Successfully");
            }
            else
            {
                Console.WriteLine("File Not Found");
            }

        }
        }
}
