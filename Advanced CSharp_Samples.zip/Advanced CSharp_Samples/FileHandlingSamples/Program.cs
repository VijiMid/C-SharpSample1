﻿using System;

namespace FileHandlingSamples
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
              File1 f1 = new File1();
              f1.display();
            */
            /*
          File2 f2 = new File2();
          f2.display();
          */
            /*   File3 f3 = new File3();
               f3.display();
            */
            /*     File4 f4 = new File4();
                 f4.display();
            */
            /* File5 f5 = new File5();
             f5.display();
            */
            File6 f6 = new File6();
            f6.display();
        }
    }
}
