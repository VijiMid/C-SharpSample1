﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Client
{
    public string CliId = "C001";
    public string CliName = "Amazon";
}
struct Location
{
    public static string LocId = "L001";
    public static string LocName = "US";
}
namespace StructSamples
{
    class Struct4
    {
        public void displayClass(Client c)
        {
            Console.WriteLine("Client Id : {0}\nClient Name : {1} ", c.CliId, c.CliName);
        }
        public void displayStruct( )
        {
            Console.WriteLine("Location Id : {0}\nLocation Name : {1} ", Location.LocId, Location.LocName);
        }
    }
}
