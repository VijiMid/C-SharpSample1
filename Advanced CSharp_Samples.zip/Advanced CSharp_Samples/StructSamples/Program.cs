﻿using System;

namespace StructSamples
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            Struct1 st = new Struct1(); // Class Name  Struct1 
            st.display(); // Method of Class

            Console.WriteLine("\n\nExternal Structure using static ");
            Console.WriteLine(Add1.x + Add1.y);
            */
            /*
            Emp e = new Emp();
            e.empno = 1001;
            e.empname = "Imran";
            e.pro.ProjId = "P001";
            e.pro.ProjName = "Shopping Cart";


            Console.WriteLine("Emp No : {0}\nEmp Name : {1} \n\nProject Id : {2}\nProject Name : {3}",
            e.empno, e.empname, e.pro.ProjId, e.pro.ProjName);
            */
            /*
            int i = 0;
            Console.WriteLine("Enter the Size");

            int size = Convert.ToInt32(Console.ReadLine());
            Emp[] e = new Emp[size];
            for (i = 0; i < size; i++)
            {
                e[i].empno = Convert.ToInt32(Console.ReadLine());
                e[i].empname = Console.ReadLine();
                e[i].pro.ProjId = Console.ReadLine();
                e[i].pro.ProjName = Console.ReadLine();
            }
            for (i = 0; i < size; i++)
            {
                Console.WriteLine("\n\nEmp No : {0}\nEmp Name : {1} \n\nProject Id : {2}\nProject Name : {3}",
            e[i].empno, e[i].empname, e[i].pro.ProjId, e[i].pro.ProjName);
            }
            */
            Struct4 st = new Struct4();
           
            Client c = new Client();
            st.displayClass(c);
             
            st.displayStruct();
        }
    }
}
