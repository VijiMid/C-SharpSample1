﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
struct Emp
{
    public int empno;
    public string empname;
    public Project pro;
}
struct Project
{
    public string ProjId;
    public string ProjName;
}