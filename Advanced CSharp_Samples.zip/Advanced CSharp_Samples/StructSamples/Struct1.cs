﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StructSamples
{
    struct Add
    {
        public int x;
        public int y;
    }
    class Struct1
    {
       public void display()
        {
            Add a = new Add();
            a.x = 100;
            a.y = 200;
            int sum = a.x + a.y;
            Console.WriteLine("Sum is : {0}", sum);
        }
    }
}
