﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

struct Add1
{
    public static  int x=200;
    public static int y=300;
} 
