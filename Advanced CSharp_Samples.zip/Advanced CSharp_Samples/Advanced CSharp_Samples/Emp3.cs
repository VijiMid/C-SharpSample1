﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Advanced_CSharp_Samples
{
    class Emp3
    {
        private int sal = 50000;
        public void display()
        {
            Console.WriteLine("Salary : " + sal);
        }
        //accessspecifier stotageclass returntype operatorkw operator() 
        public static Emp3 operator ++(Emp3 e)
        {
            Console.WriteLine("Enter Incentive : ");
            int inc = Convert.ToInt32(Console.ReadLine());
            int pf = e.sal * 20 / 100;
            e.sal = e.sal + pf + inc;
            return e;
        }
    }
         
}
