﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Advanced_CSharp_Samples
{
    class CGIEmp
    {
        public  CGIEmp()  // default
        {
            Console.WriteLine("Display1");
        }
        public CGIEmp(int a) // single parameter
        {
            Console.WriteLine("Display 2" + a);
        }
        public CGIEmp(int a, int b) // two parameter
        {
            Console.WriteLine("Display 2" + a);
        }
        public CGIEmp(int a, float b) // diff datatype
        {
            Console.WriteLine("Display 2" + a);
        }
        public CGIEmp(float a, int b) // diff order of datatype
        {
            Console.WriteLine("Display 2" + a);
        }
        public CGIEmp(float a, float b) // diff order of datatype
        {
            Console.WriteLine("Display 2" + a);
        }
    }
}
