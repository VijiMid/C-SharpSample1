﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Advanced_CSharp_Samples
{
    class Emp1
    {
        public void display()  // default
        {
            Console.WriteLine("Display1");
        }
        public void display(int a) // single parameter
        {
            Console.WriteLine("Display 2" + a);
        }
        public void display(int a,int b) // two parameter
        {
            Console.WriteLine("Display 2" + a);
        }
        public void display(int a, float b) // diff datatype
        {
            Console.WriteLine("Display 2" + a);
        }
        public void display(float a, int b) // diff order of datatype
        {
            Console.WriteLine("Display 2" + a);
        }
        public   void display(float a, float b) // diff order of datatype
        {
            Console.WriteLine("Display 2" + a);
        }
        /* - Error
        public string display() // Return type wont consider
        {
            Console.WriteLine("Display 2" + a);
            return "hello";
        }
        protected string display() // Access specifier wont consider
        {
            Console.WriteLine("Display 2" + a);
            return "hello";
        }
        static string display() // Storage class wont consider
        {
            Console.WriteLine("Display 2" + a);
            return "hello";
        }
        */
    }
}

/*
 * Return type, access specifier, storage class wont consider in method overloading
 * parameters should be diff
 * Order of datatype should be differ
 * */