﻿using System;

namespace Advanced_CSharp_Samples
{
    class Emp
    {
        public void EmpSalary1(int sal)
        {
            sal = sal + 1000;
            Console.WriteLine("Salary is : {0}", sal); //71000
        }
        public void EmpSalary2(ref int sal)
        {
            sal = sal + 2000;
            Console.WriteLine("Salary is : {0}", sal);
        }
    }
    class Program
    {
        /*
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Emp Salary : ");
            int s = Convert.ToInt32(Console.ReadLine());
            Emp e = new Emp();
            Console.WriteLine("Object Reference : " + e); // Project reference
            e.EmpSalary1(s); // Call by val
            Console.WriteLine("Salary in Call by value : " + s); // 70000

            e.EmpSalary2(ref s);
            Console.WriteLine("Salary in Call by Reference : " + s); // 72000
        }
        */
        /*
        static void Main(string[] args)
        {
            Emp1 e = new Emp1();
            e.display();
            e.display(100);
            e.display(1000.00f, 2000.00f);
            e.display(2000.00f, 1000);
            e.display(1000, 3000.00f);
            e.display(500, 600);

        }
        */
        /*
        static void Main(string[] args)
        {
            CGIEmp cgi = new CGIEmp(); // call default constructor
             
            cgi = new CGIEmp(100);
            cgi = new CGIEmp(1000.0f, 2000.00f);
            cgi = new CGIEmp(2000.00f, 1000);
            cgi = new CGIEmp(1000, 3000.00f);
            cgi = new CGIEmp(500, 600);
        }
        */
        static void Main(string[] args)
        {
            Emp3 e = new Emp3();
            e.display();
            ++e;
            e.display();

        }
    }
}
