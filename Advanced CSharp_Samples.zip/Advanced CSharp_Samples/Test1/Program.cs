﻿using System;

namespace Test1
{
    class Program
    {
        static void Main(string[] args)
        {
            Emp1 e = new Emp1();
            Console.WriteLine("Hello World!");
        }
    }
}
