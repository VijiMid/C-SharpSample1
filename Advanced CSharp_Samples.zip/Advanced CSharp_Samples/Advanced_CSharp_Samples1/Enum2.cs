﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Advanced_CSharp_Samples1
{
    class Enum2
    {
        public enum students:byte
        {
            Himanshu=10, Imran=1, Indhumathi=4, Jakatheeswar=6, Janapriya=5, Jitendra=7, Jounitta=9, Pavan=3
        }
    }
}
