﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Advanced_CSharp_Samples1
{
    class Enum1
    {
        public enum students
        {
            Himanshu,Imran,Indhumathi,Jakatheeswar,Janapriya,Jitendra,Jounitta,Pavan
        }
    }
}
