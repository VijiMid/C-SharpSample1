﻿using System;

namespace Advanced_CSharp_Samples1
{
    class Program
    {
        /*
        static void Main(string[] args)
        {
            Enum1 en = new Enum1();
            Advanced_CSharp_Samples1.Enum1.students s = Advanced_CSharp_Samples1.Enum1.students.Janapriya;
            // Console.WriteLine(s);
            Advanced_CSharp_Samples1.Enum2.students s1 = Advanced_CSharp_Samples1.Enum2.students.Janapriya;
            EvaluateEnum(s);
            Console.WriteLine("******************************");
            EvaluateEnum(s1);
        }
        static void EvaluateEnum(System.Enum e)
        {
            Console.WriteLine("Information : {0}", e.GetType().Name);
            Console.WriteLine("Storage Type : {0}", Enum.GetUnderlyingType(e.GetType()));
            Array arr = Enum.GetValues(e.GetType());
            Console.WriteLine("Member Count : {0}",arr.Length);
            for(int i=0;i<arr.Length;i++)
            {
                Console.WriteLine("Name : {0}, value :{0:D}", arr.GetValue(i));
            }
        }
        */
        /*
        static void Main(string[] args)
        {
            Advanced_CSharp_Samples1.Enum1.students s = (Advanced_CSharp_Samples1.Enum1.students)4;
            if(Enum.IsDefined(s.GetType(),s))
            {
                Console.WriteLine("Constant value defined");
            }
            else
            {
                Console.WriteLine("Constant value not defined");
            }
        }
        */
        /*
        static void Main(string[] args)
        {
            Advanced_CSharp_Samples1.Enum2.students s;
            s = Advanced_CSharp_Samples1.Enum2.students.Pavan;
            stufunc(s);
        }
        public static void stufunc(Advanced_CSharp_Samples1.Enum2.students s)
        {
            switch(s) // int, char, object of enum
            {
                case Advanced_CSharp_Samples1.Enum2.students.Imran:
                    Console.WriteLine("Student Name Imran");
                    break;
                case Advanced_CSharp_Samples1.Enum2.students.Indhumathi:
                    Console.WriteLine("Student Name Indumathi");
                    break;
                case Advanced_CSharp_Samples1.Enum2.students.Jakatheeswar:
                    Console.WriteLine("Student Name Jakatheeswar");
                    break;
                case Advanced_CSharp_Samples1.Enum2.students.Jitendra:
                    Console.WriteLine("Student Name Jitendra");
                    break;
                default:
                    Console.WriteLine("Not in case conditions");
                    break;
            }
        }
        */
        static void Main(string[] args)
        {        
            Advanced_CSharp_Samples1.Enum2.students s = Advanced_CSharp_Samples1.Enum2.students.Pavan;
        foreach(string s1 in Enum.GetNames(s.GetType()))
            {
                Console.WriteLine("Student Name :{0}", s1);
            }
        }
    }
}
